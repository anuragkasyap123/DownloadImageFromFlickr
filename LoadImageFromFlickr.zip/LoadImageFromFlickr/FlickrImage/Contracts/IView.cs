﻿namespace FlickrImage.Contracts
{
    /// <summary>
    /// Contract for View
    /// </summary>
    public interface IView
    {
    }
}