﻿using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;

namespace FlickrImage.Contracts
{
    /// <summary>
    /// Contracts for Model
    /// </summary>
    public interface IModel
    {
        void ConnectToService(string apiKey);
        ObservableCollection<BitmapImage> GetPhotos();
        string SearchItem { get; set; }
        string IsInvalidKey { get; set; }
    }
}