﻿
namespace FlickrImage.Contracts
{
    /// <summary>
    /// The logger interface.
    /// </summary>
    public interface ILogger
    {
        /// <summary>
        /// Errors the specified format.
        /// </summary>
        /// <param name="messageSource">The format.</param>
        /// <param name="message">The format.</param>
        void LogError(string messageSource, string message);

        /// <summary>
        /// Logs the specified format as information.
        /// </summary>
        /// <param name="messageSource">The format.</param>
        /// <param name="message">The format.</param>
        void LogInformation(string messageSource, string message);
    }
}