﻿using System.ComponentModel;

namespace FlickrImage.Contracts
{
    /// <summary>
    /// Contract for ViewModel
    /// </summary>
    public interface IViewModel : INotifyPropertyChanged
    {
    }
}