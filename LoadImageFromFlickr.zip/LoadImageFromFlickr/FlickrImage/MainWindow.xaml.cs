﻿#region Using Directives

using System.Windows;
using FlickrImage.View;

#endregion

namespace FlickrImage
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = flickrImageLoadView;
        }

        private readonly FlickrImageLoadView flickrImageLoadView = new FlickrImageLoadView();
    }
}
