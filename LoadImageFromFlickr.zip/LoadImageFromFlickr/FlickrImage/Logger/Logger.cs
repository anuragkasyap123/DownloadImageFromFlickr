﻿using System;
using System.Configuration;
using System.IO;
using FlickrImage.Contracts;

namespace FlickrImage.Logger
{
    /// <summary>
    ///     The Logger class.
    /// </summary>
    public sealed class Logger : ILogger
    {
        #region Public Methods

        /// <summary>
        ///     Logs the message in specified format as Error.
        /// </summary>
        /// <param name="messageSource">The message source.</param>
        /// <param name="message">The message to be logged.</param>
        public void LogError(string messageSource, string message)
        {
            Write(messageSource, LogLevel.Error, message);
        }

        /// <summary>
        ///     Logs the message in specified format as Information.
        /// </summary>
        /// <param name="messageSource">The message source.</param>
        /// <param name="message">The message to be logged.</param>
        public void LogInformation(string messageSource, string message)
        {
            Write(messageSource, LogLevel.Event, message);
        }

        #endregion

        #region Private Methods

        /// <summary>
        ///     Writes the log message to the log viewer.
        /// </summary>
        /// <param name="messageSource">Source of the message.</param>
        /// <param name="logLevel">Log level.</param>
        /// <param name="message">Message to be logged.</param>
        private static void Write(string messageSource, LogLevel logLevel, string message)
        {
            var filePath = ConfigurationManager.AppSettings["LogFilePath"];
            var content = $"Source:{messageSource}, Level:{logLevel}, Message:{message}, at {DateTime.Now}";
            using (var outputFile = File.AppendText(filePath))
            {
                outputFile.WriteLine(content);
            }
        }

        #endregion
    }
}