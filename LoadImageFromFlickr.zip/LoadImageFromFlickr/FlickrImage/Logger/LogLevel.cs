﻿namespace FlickrImage.Logger
{
    /// <summary>LogLevel enumerates the possible logging levels.</summary>
    public enum LogLevel
    {
        /// <summary>
        /// Problem that needs user intervention (e.g. unable to read from device)
        /// </summary>
        Error,

        /// <summary>
        /// Event (execution of an operation, e.g. application launch)
        /// </summary>
        Event,
    }
}
