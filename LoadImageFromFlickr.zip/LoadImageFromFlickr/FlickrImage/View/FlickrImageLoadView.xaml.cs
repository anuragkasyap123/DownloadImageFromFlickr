﻿#region Using Directives

using FlickrImage.Contracts;
using FlickrImage.ViewModels;
using System.Windows.Controls;

#endregion

namespace FlickrImage.View
{
    /// <summary>
    /// Interaction logic for FlickrImageLoadView.xaml
    /// </summary>
    public partial class FlickrImageLoadView : UserControl, IView
    {
        public FlickrImageLoadView()
        {
            InitializeComponent();
            DataContext = flickrImageLoadViewModel;
        }

        private readonly FlickrImageLoadViewModel flickrImageLoadViewModel = new FlickrImageLoadViewModel();
    }
}

