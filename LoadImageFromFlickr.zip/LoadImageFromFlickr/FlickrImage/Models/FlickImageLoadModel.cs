﻿
#region Using Directives

using System;
using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using FlickrImage.Contracts;
using FlickrNet;

#endregion

namespace FlickrImage.Models
{
    /// <summary>
    /// FlickImageLoadModel Model
    /// </summary>
    public class FlickImageLoadModel : IModel
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public FlickImageLoadModel()
        {
            logger = new Logger.Logger();
        }

        /// <summary>
        /// Constructor for Unit test.
        /// </summary>
        /// <param name="testLogger"></param>
        public FlickImageLoadModel(ILogger testLogger)
        {
            logger = testLogger;
        }

        #region public properties

        public string SearchItem { get; set; }
        public string IsInvalidKey { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Getting instance of service flickr Nuget
        /// </summary>
        public void ConnectToService(string apiKey)
        {
            if (apiKey == string.Empty) return;
            flickr = new Flickr(apiKey);
            logger.LogInformation(nameof(FlickImageLoadModel), $"API:{nameof(ConnectToService)}, " +
                                                               $"Connected to service with key {apiKey}");
        }

        /// <summary>
        /// return PhotoCollection
        /// </summary>
        /// <returns></returns>
        public ObservableCollection<BitmapImage> GetPhotos()
        {
            try
            {
                IsInvalidKey = string.Empty;
                if (flickr == null) return lstImage; 
                var options = new PhotoSearchOptions
                {
                    Tags = SearchItem,
                    PerPage = 50,
                    Page = 2
                };

                var photoCollection = flickr.PhotosSearch(options);
                logger.LogInformation(nameof(FlickImageLoadModel), $"API:{nameof(GetPhotos)}, " +
                                                                   $"PhotosSearch completed of {SearchItem}");
                lstImage = new ObservableCollection<BitmapImage>();
                foreach (var photo in photoCollection)
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri(photo.LargeUrl);
                    bitmap.EndInit();
                    lstImage.Add(bitmap);
                }

                logger.LogInformation(nameof(FlickImageLoadModel), $"API:{nameof(GetPhotos)}, " + 
                                                                   $"Photos fetching completed of {SearchItem}");
            }
            catch (Exception ex)
            {
                logger.LogError(nameof(FlickImageLoadModel),
                    $"API:{nameof(GetPhotos)}, " + $"Error in getting photos: {ex}");
                IsInvalidKey = "Error:" + ex.Message;
            }

            return lstImage;
        }

        #endregion

        #region Private properties

        private Flickr flickr;
        private readonly ILogger logger;
        ObservableCollection<BitmapImage> lstImage = new ObservableCollection<BitmapImage>();

        #endregion
    }
}

