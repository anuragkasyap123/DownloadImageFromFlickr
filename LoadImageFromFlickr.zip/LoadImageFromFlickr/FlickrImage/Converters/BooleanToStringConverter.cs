﻿#region Using Directives

using System;
using System.Globalization;
using System.Windows.Data;

#endregion

namespace FlickrImage.Converters
{
    /// <summary>
    /// Convert between boolean and content
    /// </summary>
    public class BooleanToStringConverter : IValueConverter
    {
        /// <summary>
        /// Convert bool or Nullable&lt;bool&gt; to content
        /// </summary>
        /// <param name="value">bool or Nullable&lt;bool&gt;</param>
        /// <param name="targetType">content</param>
        /// <param name="parameter">null</param>
        /// <param name="culture">null</param>
        /// <returns>Connected or Disconnected</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var bValue = default(bool);
            if (value != null && value.GetType().Name.Contains("Boolean"))
            {
                bValue = (bool) value;
            }

            return (bValue) ? Connected : DisConnected;
        }

        /// <summary>
        /// Convert Content to boolean
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string status)
            {
                return string.CompareOrdinal(status, Connected);
            }

            return false;
        }

        private const string Connected = "Connected";
        private const string DisConnected = "Disconnected";
    }
}