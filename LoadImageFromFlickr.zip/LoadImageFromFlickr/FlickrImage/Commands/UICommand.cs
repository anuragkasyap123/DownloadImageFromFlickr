﻿#region Using Directives

using System;
using System.Windows.Input;

#endregion

namespace FlickrImage.Commands
{
    /// <summary>
    /// UICommand
    /// </summary>
    public class UiCommand : ICommand
    {
        private readonly Predicate<object> canExecute;
        private readonly Action<object> executeWithParam;
        
        /// <summary>
        /// Constructor to initialize command properties.
        /// </summary>
        /// <param name="canExecute"></param>
        /// <param name="executeWithParam"></param>
        public UiCommand(Predicate<object> canExecute, Action<object> executeWithParam)
        {
            this.canExecute = canExecute;
            this.executeWithParam = executeWithParam;
        }

        /// <summary>
        ///  Constructor to initialize command properties.
        /// </summary>
        /// <param name="executeWithParam"></param>
        public UiCommand(Action<object> executeWithParam)
        {
            this.executeWithParam = executeWithParam;
            canExecute = item => true;
        }

        /// <summary>
        /// EventHandler to know Command Execution feasibility.
        /// </summary>
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }

        /// <summary>
        /// Method to determine whether this command is enabled for execution.
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns>boolean</returns>
        public bool CanExecute(object parameter)
        {
            return canExecute(parameter);
        }

        /// <summary>
        /// Method to be executed when command is invoked.
        /// </summary>
        /// <param name="parameter"></param>
        public void Execute(object parameter)
        {
            executeWithParam(parameter);
        }
    }
}