﻿
#region Using Directives

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using FlickrImage.Commands;
using FlickrImage.Contracts;
using FlickrImage.Models;

#endregion

namespace FlickrImage.ViewModels
{
    /// <summary>
    /// ViewModel for FlickrImageLoad
    /// </summary>
    public sealed class FlickrImageLoadViewModel : IViewModel
    {
        #region Constructor

        /// <summary>
        /// Constructor to initialize the Model 
        /// </summary>
        public FlickrImageLoadViewModel()
        {
            Initialize();
            logger = new Logger.Logger();
        }

        /// <summary>
        /// Constructor for Unit testing
        /// </summary>
        public FlickrImageLoadViewModel(IModel testModel)
        {
            model = testModel;
            logger = new Logger.Logger();
        }

        #endregion

        #region public members

        /// <summary>
        /// PropertyChangedEventHandler declaration
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;


        public string SearchText
        {
            get => searchText;
            set
            {
                if (searchText != value)
                {
                    searchText = value;
                    OnPropertyChanged();
                }
            }
        }

        public string ApiKey
        {
            get => apiKey;
            set
            {
                if (apiKey != value)
                {
                    apiKey = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsConnected
        {
            get => isConnected;
            set
            {
                isConnected = value;
                OnPropertyChanged();
            }
        }
        
        public bool IsNotFound
        {
            get => isNotFound;
            set
            {
                isNotFound = value;
                OnPropertyChanged();
            }
        }

        public string IsInvalidKey
        {
            get => isInvalidKey;
            set
            {
                isInvalidKey = value;
                OnPropertyChanged();
            }
        }


        /// <summary>
        /// This Defines the Command for connection.
        /// </summary>
        public ICommand ConnectCommand
        {
            get => connectCommand ?? (connectCommand = new UiCommand(ConnectToService));
            set
            {
                connectCommand = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// This Defines the Command for Searching
        /// </summary>
        public ICommand SearchCommand
        {
            get => searchCommand ?? (searchCommand = new UiCommand(IsConnectedToFlickr, GetPhotos));
            set
            {
                searchCommand = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// This Defines the Command for clearing search
        /// </summary>
        public ICommand ClearCommand
        {
            get => clearCommand ?? (clearCommand = new UiCommand(IsConnectedToFlickr, ClearSearch));
            set
            {
                clearCommand = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<BitmapImage> PhotoCollection
        {
            get => photoCollection;
            private set
            {
                photoCollection = value;
                IsNotFound = photoCollection.Count == 0;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<string> PhotoSource
        {
            get => photoSource;
            set
            {
                photoSource = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region private methods

        private void Initialize()
        {
            isConnected = false;
            isNotFound = false;
            model = new FlickImageLoadModel();
        }

        private void ConnectToService(object parameter = null)
        {
            try
            {
                IsInvalidKey = string.Empty;
                if (ApiKey == string.Empty)
                {
                    IsConnected = false;
                    return;
                }

                model.ConnectToService(ApiKey);
                logger.LogInformation(nameof(FlickrImageLoadViewModel), $"API:{nameof(ConnectToService)}, " +
                                                                        $"Connected to service with key {apiKey}");
                IsConnected = true;
            }
            catch (Exception ex)
            {
                logger.LogError(nameof(FlickrImageLoadViewModel),
                    $"API:{nameof(ConnectToService)}, " + $"Error in Connecting to service: {ex}");
            }
        }

        private void GetPhotos(object parameter = null)
        {
            try
            {
                if (SearchText != string.Empty || string.Compare(SearchText, searchItem, StringComparison.OrdinalIgnoreCase) != 0)
                {
                    searchItem = SearchText;
                    model.SearchItem = searchItem;
                    PhotoCollection = model.GetPhotos();
                    logger.LogInformation(nameof(FlickrImageLoadViewModel), $"API:{nameof(GetPhotos)}, " +
                                                                            $"Photos fetching completed of {searchItem}");
                }

                IsNotFound = PhotoCollection.Count == 0;
                InvalidKeyCheck();
            }
            catch (Exception ex)
            {
                logger.LogError(nameof(FlickrImageLoadViewModel),
                    $"API:{nameof(GetPhotos)}, " + $"Error in fetching Photos: {ex}");
            }
        }

        private void InvalidKeyCheck()
        {
            IsInvalidKey = model.IsInvalidKey;
            if (IsInvalidKey != string.Empty) IsConnected = false;
        }

        private void ClearSearch(object parameter = null)
        {
            try
            {
                if (SearchText == string.Empty) return;
                Reset();
                logger.LogInformation(nameof(FlickrImageLoadViewModel), $"API:{nameof(ClearSearch)}, " +
                                                                        $"clearing old search completedsss");
            }
            catch (Exception ex)
            {
                logger.LogError(nameof(FlickrImageLoadViewModel),
                    $"API:{nameof(ClearSearch)}, " + $"Error in clearing old search: {ex}");
            }
        }

        private void Reset()
        {
            PhotoCollection = new ObservableCollection<BitmapImage>();
            IsNotFound = false;
            SearchText = string.Empty;
            model.SearchItem = string.Empty;
        }


        /// <summary>
        /// Event that will be invoked when any property changes.
        /// </summary>
        /// <param name="propertyName"></param>
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private bool IsConnectedToFlickr(object parameter = null) => IsConnected;

        #endregion

        #region private Members

        private IModel model;
        private bool isConnected;
        private bool isNotFound;
        private string isInvalidKey;
        private string searchText;
        private string searchItem;
        private ICommand clearCommand;
        private ICommand searchCommand;
        private ICommand connectCommand;
        private ObservableCollection<string> photoSource;
        private readonly ILogger logger;
        private ObservableCollection<BitmapImage> photoCollection;
        private string apiKey = "bc91bed7d2691253a1598c8e37283926";

        #endregion
    }
}

