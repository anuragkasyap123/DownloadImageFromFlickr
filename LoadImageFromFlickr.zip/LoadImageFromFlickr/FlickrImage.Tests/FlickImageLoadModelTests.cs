﻿#region Using Directives

using FlickrImage.Contracts;
using FlickrImage.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using Rhino.Mocks;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

#endregion

namespace FlickrImage
{
    /// <summary>
    ///     The test class for <see cref="FlickImageLoadModelTests" />
    /// </summary>
    [TestFixture]
    [RequiresMTA]
    public class FlickImageLoadModelTests
    {
        /// <summary>
        ///     The test setup.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            logger = MockRepository.GenerateMock<ILogger>();
            logger.Expect(x => x.LogError(Arg<string>.Is.Anything, Arg<string>.Is.Anything));
            logger.Expect(x => x.LogInformation(Arg<string>.Is.Anything, Arg<string>.Is.Anything));
            flickImageLoadModel = new FlickImageLoadModel(logger);
            flickrPrivateObject = new PrivateObject(flickImageLoadModel);
        }

        /// <summary>
        /// Clear all the object reference.
        /// </summary>
        [TearDown]
        public void TestTearDown()
        {
            logger = null;
            flickImageLoadModel = null;
            flickrPrivateObject = null;
        }


        /// <summary>
        /// Test ConnectToService api.
        /// Checks if Flickr instance is created or not.
        /// </summary>
        [Test]
        public void ConnectToServiceTest()
        {
            flickImageLoadModel.ConnectToService("TestApiKey");
            var flickrInstance = flickrPrivateObject.GetField("flickr");
            Assert.IsNotNull(flickrInstance);
        }

        /// <summary>
        /// Test ConnectToService api.
        /// Checks if Flickr instance is created or not in negative test.
        /// </summary>
        [Test]
        public void ConnectToServiceNegativeTest()
        {
            flickImageLoadModel.ConnectToService(string.Empty);
            var flickrInstance = flickrPrivateObject.GetField("flickr");
            Assert.IsNull(flickrInstance);
        }

        /// <summary>
        /// Test GetPhotos api.
        /// Checks if PhotoCollection is populated or not.
        /// </summary>
        [Test]
        public void GetPhotosTest()
        {
            flickImageLoadModel.ConnectToService(apiKey);
            flickImageLoadModel.SearchItem = "Nature";
            var photoCollection = flickImageLoadModel.GetPhotos();
            if (flickImageLoadModel.IsInvalidKey == string.Empty)
                Assert.AreNotEqual(photoCollection.Count, 0);
            else
                logger.AssertWasCalled(x => x.LogError(Arg<string>.Is.Anything, Arg<string>.Is.Anything));
        }

        /// <summary>
        /// Test GetPhotos api.
        /// Checks if PhotoCollection count is zero.
        /// </summary>
        [Test]
        public void GetPhotosNagativeTest()
        {
            flickImageLoadModel.ConnectToService("");
            flickImageLoadModel.SearchItem = "Nature";
            var photoCollection = flickImageLoadModel.GetPhotos();
            Assert.AreEqual(photoCollection.Count, 0);
        }

        #region "Private Properies"

        private ILogger logger;
        private PrivateObject flickrPrivateObject;
        private FlickImageLoadModel flickImageLoadModel;
        private string apiKey = "bc91bed7d2691253a1598c8e37283927";

        #endregion
    }
}