﻿#region Using Directives

using System;
using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using FlickrImage.Contracts;
using FlickrImage.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using Rhino.Mocks;
using Assert = NUnit.Framework.Assert;

#endregion

namespace FlickrImage
{
    /// <summary>
    ///     The test class for <see cref="FlickImageLoadViewModelTests" />
    /// </summary>
    [TestFixture]
    [RequiresMTA]
    public class FlickImageLoadViewModelTests
    {
        /// <summary>
        ///     The test setup.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            model = MockRepository.GenerateMock<IModel>();
            logger = MockRepository.GenerateMock<ILogger>();
        }

        /// <summary>
        /// Clear all the object reference.
        /// </summary>
        [TearDown]
        public void TestTearDown()
        {
            model = null;
            logger = null;
            flickrImageLoadViewModel = null;
            flickrImageLoadViewModelPrivateObject = null;
        }

        #region Tests

        /// <summary>
        /// Test ConnectToService api.
        /// Checks if Flickr instance is created or not.
        /// </summary>
        [Test]
        public void ConnectToServiceTest()
        {
            model.Expect(x => x.ConnectToService(Arg<string>.Is.Anything)).Repeat.Once();
            SetPrivateObject("Test");
            object[] parameters =
            {
                new object()
            };

            void TestDelegate()
            {
                flickrImageLoadViewModelPrivateObject.Invoke("ConnectToService", parameters);
            }

            Assert.DoesNotThrow(TestDelegate,
                "Error thrown during the Build Request");
        }

        /// <summary>
        /// Test ConnectToService api.
        /// Checks ConnectToService by mocking error.
        /// </summary>
        [Test]
        public void ConnectToServiceNegativeTest()
        {
            model.Expect(x => x.ConnectToService(Arg<string>.Is.Anything)).Throw(new Exception());
            SetPrivateObject("Test");
            object[] parameters =
            {
                new object()
            };

            flickrImageLoadViewModelPrivateObject.Invoke("ConnectToService", parameters);

            logger.AssertWasCalled(x => x.LogError(Arg<string>.Is.Anything, Arg<string>.Is.Anything));
        }

        /// <summary>
        /// Test GetPhotos api.
        /// </summary>
        [Test]
        public void GetPhotosTest()
        {
            model.Expect(x => x.GetPhotos()).Return(new ObservableCollection<BitmapImage>());
            SetPrivateObject("Test");
            object[] parameters =
            {
                new object()
            };

            void TestDelegate()
            {
                flickrImageLoadViewModelPrivateObject.Invoke("GetPhotos", parameters);
            }

            Assert.DoesNotThrow(TestDelegate,
                "Error thrown during the Build Request");
        }

        /// <summary>
        /// Test GetPhotos api when search item is empty.
        /// </summary>
        [Test]
        public void GetPhotosEmptySearchTest()
        {
            model.Expect(x => x.GetPhotos()).Return(new ObservableCollection<BitmapImage>());
            SetPrivateObject("");
            object[] parameters =
            {
                new object()
            };

            flickrImageLoadViewModelPrivateObject.Invoke("GetPhotos", parameters);

            Assert.AreEqual(flickrImageLoadViewModel.PhotoCollection.Count, 0);
        }

        /// <summary>
        /// Test GetPhotos api when new searchItem == previous searchItem.
        /// </summary>
        [Test]
        public void GetPhotosRepeatedSearchTest()
        {
            model.Expect(x => x.GetPhotos()).Return(new ObservableCollection<BitmapImage>());
            SetPrivateObject("Test");
            flickrImageLoadViewModelPrivateObject.SetField("searchItem", "test");
            object[] parameters =
            {
                new object()
            };

            flickrImageLoadViewModelPrivateObject.Invoke("GetPhotos", parameters);

            Assert.AreEqual(flickrImageLoadViewModel.PhotoCollection.Count, 0);
        }

        /// <summary>
        /// Test GetPhotos api.
        /// Checks GetPhotos by mocking error.
        /// </summary>
        [Test]
        public void GetPhotosNegativeTest()
        {
            model.Expect(x => x.GetPhotos()).Throw(new Exception());
            SetPrivateObject("Test");
            object[] parameters =
            {
                new object()
            };

            flickrImageLoadViewModelPrivateObject.Invoke("GetPhotos", parameters);

            logger.AssertWasCalled(x => x.LogError(Arg<string>.Is.Anything, Arg<string>.Is.Anything));
        }

        /// <summary>
        /// Test GetPhotos api when new searchItem == previous searchItem.
        /// </summary>
        [Test]
        public void ClearSearchTest()
        {
            SetPrivateObject("Test");
            flickrImageLoadViewModelPrivateObject.SetField("searchItem", "test");
            object[] parameters =
            {
                new object()
            };

            flickrImageLoadViewModelPrivateObject.Invoke("ClearSearch", parameters);

            Assert.IsEmpty(flickrImageLoadViewModel.SearchText);
            Assert.AreEqual(flickrImageLoadViewModel.PhotoCollection, new ObservableCollection<BitmapImage>());
        }

        #endregion

        #region private methods

        private void SetPrivateObject(string searchItem)
        {
            logger.Expect(x => x.LogError(Arg<string>.Is.Anything, Arg<string>.Is.Anything));
            logger.Expect(x => x.LogInformation(Arg<string>.Is.Anything, Arg<string>.Is.Anything));
            flickrImageLoadViewModel = new FlickrImageLoadViewModel(model, logger) {SearchText = searchItem};
            flickrImageLoadViewModelPrivateObject = new PrivateObject(flickrImageLoadViewModel);
        }

        #endregion

        #region "Private Properies" 

        private IModel model;
        private ILogger logger;
        private FlickrImageLoadViewModel flickrImageLoadViewModel;
        private PrivateObject flickrImageLoadViewModelPrivateObject;

        #endregion
    }
}