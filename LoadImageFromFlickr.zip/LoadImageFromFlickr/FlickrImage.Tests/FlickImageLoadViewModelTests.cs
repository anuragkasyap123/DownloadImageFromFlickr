﻿#region Using Directives

using System;
using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using FlickrImage.Contracts;
using FlickrImage.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using Rhino.Mocks;
using Assert = NUnit.Framework.Assert;

#endregion

namespace FlickrImage
{
    /// <summary>
    ///     The test class for <see cref="FlickImageLoadViewModelTests" />
    /// </summary>
    [TestFixture]
    [RequiresMTA]
    public class FlickImageLoadViewModelTests
    {
        /// <summary>
        ///     The test setup.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            model = MockRepository.GenerateMock<IModel>();
        }

        /// <summary>
        /// Clear all the object reference.
        /// </summary>
        [TearDown]
        public void TestTearDown()
        {
            model = null;
            flickrImageLoadViewModel = null;
            flickrImageLoadViewModelPrivateObject = null;
        }

        #region Tests

        /// <summary>
        /// Test ConnectToService api.
        /// Checks if Flickr instance is created or not.
        /// </summary>
        [Test]
        public void ConnectToServiceTest()
        {
            model.Expect(x => x.ConnectToService(Arg<string>.Is.Anything)).Repeat.Once();
            SetPrivateObject("Test");
            object[] parameters =
            {
                new object()
            };

            void TestDelegate()
            {
                flickrImageLoadViewModelPrivateObject.Invoke("ConnectToService", parameters);
            }

            Assert.DoesNotThrow(TestDelegate,
                "Error thrown during the Build Request");
        }

        /// <summary>
        /// Test ConnectToService api.
        /// Checks ConnectToService by mocking error.
        /// </summary>
        [Test]
        public void ConnectToServiceNegativeTest()
        {
            model.Expect(x => x.ConnectToService(Arg<string>.Is.Anything)).Throw(new Exception());
            SetPrivateObject("Test");
            object[] parameters =
            {
                new object()
            };

            void TestDelegate()
            {
                flickrImageLoadViewModelPrivateObject.Invoke("ConnectToService", parameters);
            }

            Assert.Throws<Exception>(TestDelegate);
        }

        /// <summary>
        /// Test GetPhotos api.
        /// </summary>
        [Test]
        public void GetPhotosTest()
        {
            model.Expect(x => x.GetPhotos()).Return(new ObservableCollection<BitmapImage>());
            SetPrivateObject("Test");
            object[] parameters =
            {
                new object()
            };

            void TestDelegate()
            {
                flickrImageLoadViewModelPrivateObject.Invoke("GetPhotos", parameters);
            }

            Assert.DoesNotThrow(TestDelegate,
                "Error thrown during the Build Request");
        }

        /// <summary>
        /// Test GetPhotos api when search item is empty.
        /// </summary>
        [Test]
        public void GetPhotosEmptySearchTest()
        {
            model.Expect(x => x.GetPhotos()).Return(new ObservableCollection<BitmapImage>());
            SetPrivateObject("");
            object[] parameters =
            {
                new object()
            };

            flickrImageLoadViewModelPrivateObject.Invoke("GetPhotos", parameters);

            Assert.IsNull(flickrImageLoadViewModel.PhotoCollection);
        }

        /// <summary>
        /// Test GetPhotos api when new searchItem == previous searchItem.
        /// </summary>
        [Test]
        public void GetPhotosRepeatedSearchTest()
        {
            model.Expect(x => x.GetPhotos()).Return(new ObservableCollection<BitmapImage>());
            SetPrivateObject("Test");
            flickrImageLoadViewModelPrivateObject.SetField("searchItem", "test");
            object[] parameters =
            {
                new object()
            };

            flickrImageLoadViewModelPrivateObject.Invoke("GetPhotos", parameters);

            Assert.IsNull(flickrImageLoadViewModel.PhotoCollection);
        }

        /// <summary>
        /// Test GetPhotos api.
        /// Checks GetPhotos by mocking error.
        /// </summary>
        [Test]
        [Microsoft.VisualStudio.TestTools.UnitTesting.ExpectedException(typeof(Exception))]
        public void GetPhotosNegativeTest()
        {
            model.Expect(x => x.GetPhotos()).Throw(new Exception());
            SetPrivateObject("Test");
            object[] parameters =
            {
                new object()
            };

            void TestDelegate()
            {
                flickrImageLoadViewModelPrivateObject.Invoke("GetPhotos", parameters);
            }

            Assert.Throws<Exception>(TestDelegate);
        }

        /// <summary>
        /// Test GetPhotos api when new searchItem == previous searchItem.
        /// </summary>
        [Test]
        public void ClearSearchTest()
        {
            SetPrivateObject("Test");
            flickrImageLoadViewModelPrivateObject.SetField("searchItem", "test");
            object[] parameters =
            {
                new object()
            };

            flickrImageLoadViewModelPrivateObject.Invoke("ClearSearch", parameters);

            Assert.IsEmpty(flickrImageLoadViewModel.SearchText);
            Assert.AreEqual(flickrImageLoadViewModel.PhotoCollection, new ObservableCollection<BitmapImage>());
        }

        #endregion

        #region private methods

        private void SetPrivateObject(string searchItem)
        {
            flickrImageLoadViewModel = new FlickrImageLoadViewModel(model) {SearchText = searchItem};
            flickrImageLoadViewModelPrivateObject = new PrivateObject(flickrImageLoadViewModel);
        }

        #endregion

        #region "Private Properies" 

        private FlickrImageLoadViewModel flickrImageLoadViewModel;
        private PrivateObject flickrImageLoadViewModelPrivateObject;
        private IModel model;

        #endregion
    }
}